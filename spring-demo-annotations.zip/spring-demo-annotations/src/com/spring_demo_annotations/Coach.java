package com.spring_demo_annotations;

public interface Coach {
	
	public String getDailyWorkout();

}
